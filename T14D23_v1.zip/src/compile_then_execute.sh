rm -f output_datasets/*
cp ../datasets/* output_datasets

#make rebuild && (echo "output_datasets/door_state_1 0" | ../build/Quest_1)
#make rebuild && (echo "output_datasets/door_state_1 1" | ../build/Quest_1)
#make rebuild && (echo "output_datasets/door_state_1 2 2040 9 1 12 0 0 0 153" | ../build/Quest_1)

#make rebuild && (echo "output_datasets/door_state_2 01.09.2020" | ../build/Quest_2)

make rebuild && (echo "output_datasets/door_state_3 21.09.1945 18.10.1945" | ../build/Quest_3)