#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "file_record.h"
#include "date.h"


int main() {
    char file_path[1024];
    t_date input_date;

    int error_amount = 0;
    scanf("%s", file_path);
    scan_date_from_console(&input_date);

    if (error_amount > 0) {
        printf("n/a\n");
        return 0;
    }

    FILE *input_file_pointer = fopen(file_path, "r+b");
    if (input_file_pointer != NULL) {
        int record_amount = get_record_amount(input_file_pointer);
        t_file_record record;
        for (int record_index = 0; record_index < record_amount; record_index++) {
            error_amount += read_record_from_file_at_index(input_file_pointer, record_index, &record);
            if (error_amount > 0) {
                break;
            }
            if (record.year == input_date.year && record.month == input_date.month && record.day == input_date.day) {
                printf("%d\n", record.code);
                break;
            }
        }
        fclose(input_file_pointer);
    } else {
        error_amount++;
    }

    if (error_amount > 0) {
        printf("n/a\n");
    }
    return 0;
}