#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "file_record.h"

int main() {
    int mode;
    char file_path[1024];

    scanf("%s", file_path);
    scanf("%d", &mode);

    int error_amount = 0;
    FILE *input_file_pointer = fopen(file_path, "r+b");
    if (input_file_pointer == NULL) {
        error_amount++;
    } else {
        int record_amount = get_record_amount(input_file_pointer);

        if (mode == 0) {
            display_whole_file(input_file_pointer, record_amount);
        } else if (mode == 1) {
            sort_file(input_file_pointer, record_amount);
            display_whole_file(input_file_pointer, record_amount);
        } else if (mode == 2) {
            error_amount += scan_and_append_new_entry_to_file(file_path);
            if (error_amount == 0) {
                record_amount = get_record_amount(input_file_pointer);
                sort_file(input_file_pointer, record_amount);
                display_whole_file(input_file_pointer, record_amount);
            }
        } else {
            error_amount++;
        }
        fclose(input_file_pointer);
    }

    if (error_amount > 0) {
        printf("n/a\n");
    }
    return 0;
}