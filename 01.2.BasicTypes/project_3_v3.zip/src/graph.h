#ifndef GRAPH_H
#define GRAPH_H

#define DOT "*"
#define VOID "."

void create_x_array(double** x_array, int* array_size);
void print_result(double* y_array);

#endif
