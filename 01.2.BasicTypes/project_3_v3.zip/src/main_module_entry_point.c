#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stack.h"
#include "graph.h"
#include "numeric_stack.h"
#include "tokenizer.h"
#include "token_computation.h"
#include "full_computation.h"
#include "shunting_yard_algo.h"

int main() {
    int has_error = 0;
    int x_array_size;
    double* x_array;
    double* y_array;

    char input_string[1024];
    scanf("%s", input_string);

    create_x_array(&x_array, &x_array_size);
    has_error = create_y_array(x_array, &y_array, x_array_size, input_string);
    if (has_error) {
        printf("FAIL\n");
    } else {
        print_result(y_array);
    }

    free(x_array);
    free(y_array);
    return 0;
}
