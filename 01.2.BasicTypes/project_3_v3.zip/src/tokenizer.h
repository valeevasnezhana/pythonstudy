#ifndef TOKENIZER_H
#define TOKENIZER_H

#include "token.h"

int create_token_array(char* input_string, struct token** token_array, int* token_amount);

#endif