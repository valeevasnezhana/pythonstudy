#make build_main && (echo "sin(cos(-2*x))" | ../build/main_module_entry_point)
#make build_main && (echo "1-x*0.2" | ../build/main_module_entry_point)
make build_main && (echo "1-x*0.2/ln(10.0)" | ../build/main_module_entry_point)