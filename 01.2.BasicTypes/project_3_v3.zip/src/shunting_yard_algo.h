#ifndef SHUNTING_YARD_ALGO_H
#define SHUNTING_YARD_ALGO_H

int apply_shunting_yard_algo(struct token* input_token_array, int input_token_amount, struct token** output_token_array, int* output_token_amount);

#endif
