#include "date.h"

#include <stdio.h>

int scan_date_from_string(char* input_date_string, t_date* date) {
    int read_amount = sscanf(input_date_string, "%d.%d.%d", &(date->day), &(date->month), &(date->year));
    if (read_amount == 3) {
        return 0;
    } else {
        return 1;
    }
}

int scan_date_from_console(t_date* date) {
    int error_amount = 0;
    char input_date_string[1024];
    scanf("%1023s", input_date_string);
    error_amount += scan_date_from_string(input_date_string, date);
    int read_amount = sscanf(input_date_string, "%d.%d.%d", &(date->day), &(date->month), &(date->year));
    if (error_amount == 0 && read_amount == 3) {
        return 0;
    } else {
        return 1;
    }
}
