#ifndef DATE_H
#define DATE_H

typedef struct date_raw {
    int year;
    int month;
    int day;
} t_date;

int scan_date_from_string(char* input_date_string, t_date* date);

int scan_date_from_console(t_date* date);

#endif
