#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "date.h"
#include "file_record.h"

int record_is_greater_than_date(t_file_record* record, t_date* date) {
    if (record->year < date->year) {
        return -1;
    } else if (record->year > date->year) {
        return 1;
    }

    if (record->month < date->month) {
        return -1;
    } else if (record->month > date->month) {
        return 1;
    }

    if (record->day < date->day) {
        return -1;
    } else if (record->day > date->day) {
        return 1;
    }

    return 0;
}

int main() {
    char file_path[1024];
    t_date start_date;
    t_date end_date;

    int error_amount = 0;
    scanf("%1023s", file_path);
    scan_date_from_console(&start_date);
    scan_date_from_console(&end_date);

    FILE* file_pointer = fopen(file_path, "r+b");
    if (file_pointer != NULL) {
        int initial_record_amount = get_record_amount(file_pointer);

        int write_record_index = 0;
        t_file_record current_record;
        for (int read_record_index = 0; read_record_index < initial_record_amount; read_record_index++) {
            error_amount += read_record_from_file_at_index(file_pointer, read_record_index, &current_record);
            if (error_amount > 0) {
                break;
            }
            if (record_is_greater_than_date(&current_record, &start_date) >= 0 &&
                record_is_greater_than_date(&current_record, &end_date) <= 0) {
                continue;
            }
            write_record_to_file_at_index(file_pointer, write_record_index, &current_record);
            write_record_index++;
        }
        display_whole_file(file_pointer, write_record_index);
        //        printf("Total deleted records: %d, %d, %d\n", initial_record_amount, write_record_index,
        //               initial_record_amount - write_record_index);
        truncate(file_path, write_record_index * sizeof(t_file_record));
        //        int final_record_amount = get_record_amount(file_pointer);
        //        printf("Final record amount: %d\n", final_record_amount);
        fclose(file_pointer);
    } else {
        error_amount++;
    }

    if (error_amount > 0) {
        printf("n/a\n");
        return 0;
    }
    return 0;
}
