#include "file_record.h"

#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int read_record_from_file_at_index(FILE* file_pointer, int record_index, t_file_record* record) {
    int return_code = 0;
    int read_obj_amount = 0;

    int offset = record_index * sizeof(t_file_record);
    fseek(file_pointer, offset, SEEK_SET);
    read_obj_amount += fread(record, sizeof(t_file_record), 1, file_pointer);
    rewind(file_pointer);

    if (read_obj_amount != 1) {
        return_code = 1;
    }
    return return_code;
}

int write_record_to_file_at_index(FILE* file_pointer, int record_index, t_file_record* record) {
    int return_code = 0;

    int written_obj_amount = 0;
    int offset = record_index * sizeof(t_file_record);
    fseek(file_pointer, offset, SEEK_SET);
    written_obj_amount = fwrite(record, sizeof(t_file_record), 1, file_pointer);
    fflush(file_pointer);
    rewind(file_pointer);

    if (written_obj_amount != 8) {
        return_code = 1;
    }
    return return_code;
}

void print_record(t_file_record* record) {
    if (record != NULL) {
        printf("%d %d %d %d %d %d %d %d\n", record->year, record->month, record->day, record->hour,
               record->minute, record->second, record->status, record->code);
    }
}

int left_record_less_than_right(t_file_record* left_record, t_file_record* right_record) {
    if (left_record->year != right_record->year) {
        return left_record->year < right_record->year;
    }
    if (left_record->month != right_record->month) {
        return left_record->month < right_record->month;
    }
    if (left_record->day != right_record->day) {
        return left_record->day < right_record->day;
    }
    if (left_record->hour != right_record->hour) {
        return left_record->hour < right_record->hour;
    }
    if (left_record->minute != right_record->minute) {
        return left_record->minute < right_record->minute;
    }
    if (left_record->second != right_record->second) {
        return left_record->second < right_record->second;
    }
    if (left_record->status != right_record->status) {
        return left_record->status < right_record->status;
    }
    return left_record->code < right_record->code;
}

int get_record_amount(FILE* input_file_pointer) {
    fseek(input_file_pointer, 0L, SEEK_END);
    long file_size_in_bytes = ftell(input_file_pointer);
    rewind(input_file_pointer);
    int record_amount = (int)file_size_in_bytes / sizeof(t_file_record);
    return record_amount;
}

void sort_file(FILE* input_file_pointer, int record_amount) {
    int previous_record_index;
    t_file_record current_record;
    t_file_record previous_record;
    for (int iteration_index = 0; iteration_index < record_amount; iteration_index++) {
        for (int current_record_index = 1; current_record_index < record_amount; current_record_index++) {
            previous_record_index = current_record_index - 1;
            read_record_from_file_at_index(input_file_pointer, current_record_index, &current_record);
            read_record_from_file_at_index(input_file_pointer, previous_record_index, &previous_record);
            if (left_record_less_than_right(&current_record, &previous_record)) {
                write_record_to_file_at_index(input_file_pointer, previous_record_index, &current_record);
                write_record_to_file_at_index(input_file_pointer, current_record_index, &previous_record);
            }
        }
    }
}

int display_whole_file(FILE* input_file_pointer, int record_amount) {
    t_file_record record;
    int has_error = 0;
    for (int record_index = 0; record_index < record_amount; record_index++) {
        has_error = read_record_from_file_at_index(input_file_pointer, record_index, &record);
        if (has_error == 1) {
            break;
        } else {
            print_record(&record);
        }
    }
    return has_error;
}

int scan_record_from_console(t_file_record* record) {
    int received_values =
        scanf("%d %d %d %d %d %d %d %d", &(record->year), &(record->month), &(record->day), &(record->hour),
              &(record->minute), &(record->second), &(record->status), &(record->code));
    if (received_values == 8) {
        return 0;
    } else {
        return 1;
    }
}

int scan_and_append_new_entry_to_file(char file_path[1024]) {
    t_file_record new_record;
    int scan_has_error = scan_record_from_console(&new_record);
    if (scan_has_error) {
        return 1;
    }

    FILE* output_file_pointer = fopen(file_path, "a");
    if (output_file_pointer == NULL) {
        return 1;
    } else {
        int written_obj_amount = fwrite(&new_record, sizeof(t_file_record), 1, output_file_pointer);
        fflush(output_file_pointer);
        fclose(output_file_pointer);
        if (written_obj_amount != 1) {
            return 1;
        }
    }
    return 0;
}
