#ifndef FILE_RECORD_H
#define FILE_RECORD_H

#include <dirent.h>
#include <stdio.h>

typedef struct file_record_raw {
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int second;
    int status;
    int code;
} t_file_record;

int read_record_from_file_at_index(FILE *file_pointer, int record_index, t_file_record* record);

int write_record_to_file_at_index(FILE *file_pointer, int record_index, t_file_record* record);

void print_record(t_file_record* record);

int left_record_less_than_right(t_file_record* left_record, t_file_record* right_record);

int get_record_amount(FILE *input_file_pointer);

void sort_file(FILE *input_file_pointer, int record_amount);

int display_whole_file(FILE *input_file_pointer, int record_amount);

int scan_record_from_console(t_file_record* record);

int scan_and_append_new_entry_to_file(char file_path[1024]);

#endif
