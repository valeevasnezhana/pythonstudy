make rebuild
echo "-------------"
echo "1-x*0.2 | -12.566370614359172"
echo "3.51327"
echo "1-x*0.2 -12.566370614359172" | ../build/test_computation
echo "-------------"
echo "1-x*0.2 | -12.08709931"
echo "3.41742"
echo "1-x*0.2 -12.08709931" | ../build/test_computation
echo "-------------"
echo "1-x*0.2 | -12.08577276"
echo "3.41715"
echo "1-x*0.2 -12.08577276" | ../build/test_computation
echo "-------------"
echo "1-x*0.2 | -10.0"
echo "3.0"
echo "1-x*0.2 -10.0" | ../build/test_computation
echo "-------------"
echo "1-x*0.2 | -8.18791434"
echo "2.63758"
echo "1-x*0.2 -8.18791434" | ../build/test_computation
echo "-------------"
echo "1-x*0.2 | -5.0"
echo "2.0"
echo "1-x*0.2 -5.0" | ../build/test_computation
echo "-------------"
echo "1-x*0.2 | -0.42312372"
echo "1.08462"
echo "1-x*0.2 -0.42312372" | ../build/test_computation
echo "-------------"
echo "1-x*0.2 | -0.348404"
echo "1.06968"
echo "1-x*0.2 -0.348404" | ../build/test_computation
echo "-------------"
echo "1-x*0.2 | 0.0"
echo "1.0"
echo "1-x*0.2 0.0" | ../build/test_computation
echo "-------------"
echo "1-x*0.2 | -0.0"
echo "1.0"
echo "1-x*0.2 -0.0" | ../build/test_computation
echo "-------------"
echo "1-x*0.2 | 0.348404"
echo "0.930319"
echo "1-x*0.2 0.348404" | ../build/test_computation
echo "-------------"
echo "1-x*0.2 | 0.42312372"
echo "0.915375"
echo "1-x*0.2 0.42312372" | ../build/test_computation
echo "-------------"
echo "1-x*0.2 | 5.0"
echo "0.0"
echo "1-x*0.2 5.0" | ../build/test_computation
echo "-------------"
echo "1-x*0.2 | 8.18791434"
echo "-0.637583"
echo "1-x*0.2 8.18791434" | ../build/test_computation
echo "-------------"
echo "1-x*0.2 | 10.0"
echo "-1.0"
echo "1-x*0.2 10.0" | ../build/test_computation
echo "-------------"
echo "1-x*0.2 | 12.08577276"
echo "-1.41715"
echo "1-x*0.2 12.08577276" | ../build/test_computation
echo "-------------"
echo "1-x*0.2 | 12.08709931"
echo "-1.41742"
echo "1-x*0.2 12.08709931" | ../build/test_computation
echo "-------------"
echo "1-x*0.2 | 12.566370614359172"
echo "-1.51327"
echo "1-x*0.2 12.566370614359172" | ../build/test_computation

echo "-------------"
echo "sin(cos(-2*x)) | -12.566370614359172"
echo "0.841471"
echo "sin(cos(-2*x)) -12.566370614359172" | ../build/test_computation
echo "-------------"
echo "sin(cos(-2*x)) | -12.08709931"
echo "0.543594"
echo "sin(cos(-2*x)) -12.08709931" | ../build/test_computation
echo "-------------"
echo "sin(cos(-2*x)) | -12.08577276"
echo "0.541769"
echo "sin(cos(-2*x)) -12.08577276" | ../build/test_computation
echo "-------------"
echo "sin(cos(-2*x)) | -10.0"
echo "0.39685"
echo "sin(cos(-2*x)) -10.0" | ../build/test_computation
echo "-------------"
echo "sin(cos(-2*x)) | -8.18791434"
echo "-0.706928"
echo "sin(cos(-2*x)) -8.18791434" | ../build/test_computation
echo "-------------"
echo "sin(cos(-2*x)) | -5.0"
echo "-0.744023"
echo "sin(cos(-2*x)) -5.0" | ../build/test_computation
echo "-------------"
echo "sin(cos(-2*x)) | -0.42312372"
echo "0.615325"
echo "sin(cos(-2*x)) -0.42312372" | ../build/test_computation
echo "-------------"
echo "sin(cos(-2*x)) | -0.348404"
echo "0.693903"
echo "sin(cos(-2*x)) -0.348404" | ../build/test_computation
echo "-------------"
echo "sin(cos(-2*x)) | 0.0"
echo "0.841471"
echo "sin(cos(-2*x)) 0.0" | ../build/test_computation
echo "-------------"
echo "sin(cos(-2*x)) | -0.0"
echo "0.841471"
echo "sin(cos(-2*x)) -0.0" | ../build/test_computation
echo "-------------"
echo "sin(cos(-2*x)) | 0.348404"
echo "0.693903"
echo "sin(cos(-2*x)) 0.348404" | ../build/test_computation
echo "-------------"
echo "sin(cos(-2*x)) | 0.42312372"
echo "0.615325"
echo "sin(cos(-2*x)) 0.42312372" | ../build/test_computation
echo "-------------"
echo "sin(cos(-2*x)) | 5.0"
echo "-0.744023"
echo "sin(cos(-2*x)) 5.0" | ../build/test_computation
echo "-------------"
echo "sin(cos(-2*x)) | 8.18791434"
echo "-0.706928"
echo "sin(cos(-2*x)) 8.18791434" | ../build/test_computation
echo "-------------"
echo "sin(cos(-2*x)) | 10.0"
echo "0.39685"
echo "sin(cos(-2*x)) 10.0" | ../build/test_computation
echo "-------------"
echo "sin(cos(-2*x)) | 12.08577276"
echo "0.541769"
echo "sin(cos(-2*x)) 12.08577276" | ../build/test_computation
echo "-------------"
echo "sin(cos(-2*x)) | 12.08709931"
echo "0.543594"
echo "sin(cos(-2*x)) 12.08709931" | ../build/test_computation
echo "-------------"
echo "sin(cos(-2*x)) | 12.566370614359172"
echo "0.841471"
echo "sin(cos(-2*x)) 12.566370614359172" | ../build/test_computation
echo "-------------"
echo "2+x+(4-3) | -12.566370614359172"
echo "-9.56637"
echo "2+x+(4-3) -12.566370614359172" | ../build/test_computation
echo "-------------"
echo "2+x+(4-3) | -12.08709931"
echo "-9.0871"
echo "2+x+(4-3) -12.08709931" | ../build/test_computation
echo "-------------"
echo "2+x+(4-3) | -12.08577276"
echo "-9.08577"
echo "2+x+(4-3) -12.08577276" | ../build/test_computation
echo "-------------"
echo "2+x+(4-3) | -10.0"
echo "-7.0"
echo "2+x+(4-3) -10.0" | ../build/test_computation
echo "-------------"
echo "2+x+(4-3) | -8.18791434"
echo "-5.18791"
echo "2+x+(4-3) -8.18791434" | ../build/test_computation
echo "-------------"
echo "2+x+(4-3) | -5.0"
echo "-2.0"
echo "2+x+(4-3) -5.0" | ../build/test_computation
echo "-------------"
echo "2+x+(4-3) | -0.42312372"
echo "2.57688"
echo "2+x+(4-3) -0.42312372" | ../build/test_computation
echo "-------------"
echo "2+x+(4-3) | -0.348404"
echo "2.6516"
echo "2+x+(4-3) -0.348404" | ../build/test_computation
echo "-------------"
echo "2+x+(4-3) | 0.0"
echo "3.0"
echo "2+x+(4-3) 0.0" | ../build/test_computation
echo "-------------"
echo "2+x+(4-3) | -0.0"
echo "3.0"
echo "2+x+(4-3) -0.0" | ../build/test_computation
echo "-------------"
echo "2+x+(4-3) | 0.348404"
echo "3.3484"
echo "2+x+(4-3) 0.348404" | ../build/test_computation
echo "-------------"
echo "2+x+(4-3) | 0.42312372"
echo "3.42312"
echo "2+x+(4-3) 0.42312372" | ../build/test_computation
echo "-------------"
echo "2+x+(4-3) | 5.0"
echo "8.0"
echo "2+x+(4-3) 5.0" | ../build/test_computation
echo "-------------"
echo "2+x+(4-3) | 8.18791434"
echo "11.1879"
echo "2+x+(4-3) 8.18791434" | ../build/test_computation
echo "-------------"
echo "2+x+(4-3) | 10.0"
echo "13.0"
echo "2+x+(4-3) 10.0" | ../build/test_computation
echo "-------------"
echo "2+x+(4-3) | 12.08577276"
echo "15.0858"
echo "2+x+(4-3) 12.08577276" | ../build/test_computation
echo "-------------"
echo "2+x+(4-3) | 12.08709931"
echo "15.0871"
echo "2+x+(4-3) 12.08709931" | ../build/test_computation
echo "-------------"
echo "2+x+(4-3) | 12.566370614359172"
echo "15.5664"
echo "2+x+(4-3) 12.566370614359172" | ../build/test_computation
echo "-------------"
echo "2*x+(4-3) | -12.566370614359172"
echo "-24.1327"
echo "2*x+(4-3) -12.566370614359172" | ../build/test_computation
echo "-------------"
echo "2*x+(4-3) | -12.08709931"
echo "-23.1742"
echo "2*x+(4-3) -12.08709931" | ../build/test_computation
echo "-------------"
echo "2*x+(4-3) | -12.08577276"
echo "-23.1715"
echo "2*x+(4-3) -12.08577276" | ../build/test_computation
echo "-------------"
echo "2*x+(4-3) | -10.0"
echo "-19.0"
echo "2*x+(4-3) -10.0" | ../build/test_computation
echo "-------------"
echo "2*x+(4-3) | -8.18791434"
echo "-15.3758"
echo "2*x+(4-3) -8.18791434" | ../build/test_computation
echo "-------------"
echo "2*x+(4-3) | -5.0"
echo "-9.0"
echo "2*x+(4-3) -5.0" | ../build/test_computation
echo "-------------"
echo "2*x+(4-3) | -0.42312372"
echo "0.153753"
echo "2*x+(4-3) -0.42312372" | ../build/test_computation
echo "-------------"
echo "2*x+(4-3) | -0.348404"
echo "0.303192"
echo "2*x+(4-3) -0.348404" | ../build/test_computation
echo "-------------"
echo "2*x+(4-3) | 0.0"
echo "1.0"
echo "2*x+(4-3) 0.0" | ../build/test_computation
echo "-------------"
echo "2*x+(4-3) | -0.0"
echo "1.0"
echo "2*x+(4-3) -0.0" | ../build/test_computation
echo "-------------"
echo "2*x+(4-3) | 0.348404"
echo "1.69681"
echo "2*x+(4-3) 0.348404" | ../build/test_computation
echo "-------------"
echo "2*x+(4-3) | 0.42312372"
echo "1.84625"
echo "2*x+(4-3) 0.42312372" | ../build/test_computation
echo "-------------"
echo "2*x+(4-3) | 5.0"
echo "11.0"
echo "2*x+(4-3) 5.0" | ../build/test_computation
echo "-------------"
echo "2*x+(4-3) | 8.18791434"
echo "17.3758"
echo "2*x+(4-3) 8.18791434" | ../build/test_computation
echo "-------------"
echo "2*x+(4-3) | 10.0"
echo "21.0"
echo "2*x+(4-3) 10.0" | ../build/test_computation
echo "-------------"
echo "2*x+(4-3) | 12.08577276"
echo "25.1715"
echo "2*x+(4-3) 12.08577276" | ../build/test_computation
echo "-------------"
echo "2*x+(4-3) | 12.08709931"
echo "25.1742"
echo "2*x+(4-3) 12.08709931" | ../build/test_computation
echo "-------------"
echo "2*x+(4-3) | 12.566370614359172"
echo "26.1327"
echo "2*x+(4-3) 12.566370614359172" | ../build/test_computation
echo "-------------"
echo "x*x*x+3+4*10 | -12.566370614359172"
echo "-1941.4"
echo "x*x*x+3+4*10 -12.566370614359172" | ../build/test_computation
echo "-------------"
echo "x*x*x+3+4*10 | -12.08709931"
echo "-1722.9"
echo "x*x*x+3+4*10 -12.08709931" | ../build/test_computation
echo "-------------"
echo "x*x*x+3+4*10 | -12.08577276"
echo "-1722.32"
echo "x*x*x+3+4*10 -12.08577276" | ../build/test_computation
echo "-------------"
echo "x*x*x+3+4*10 | -10.0"
echo "-957.0"
echo "x*x*x+3+4*10 -10.0" | ../build/test_computation
echo "-------------"
echo "x*x*x+3+4*10 | -8.18791434"
echo "-505.934"
echo "x*x*x+3+4*10 -8.18791434" | ../build/test_computation
echo "-------------"
echo "x*x*x+3+4*10 | -5.0"
echo "-82.0"
echo "x*x*x+3+4*10 -5.0" | ../build/test_computation
echo "-------------"
echo "x*x*x+3+4*10 | -0.42312372"
echo "42.9242"
echo "x*x*x+3+4*10 -0.42312372" | ../build/test_computation
echo "-------------"
echo "x*x*x+3+4*10 | -0.348404"
echo "42.9577"
echo "x*x*x+3+4*10 -0.348404" | ../build/test_computation
echo "-------------"
echo "x*x*x+3+4*10 | 0.0"
echo "43.0"
echo "x*x*x+3+4*10 0.0" | ../build/test_computation
echo "-------------"
echo "x*x*x+3+4*10 | -0.0"
echo "43.0"
echo "x*x*x+3+4*10 -0.0" | ../build/test_computation
echo "-------------"
echo "x*x*x+3+4*10 | 0.348404"
echo "43.0423"
echo "x*x*x+3+4*10 0.348404" | ../build/test_computation
echo "-------------"
echo "x*x*x+3+4*10 | 0.42312372"
echo "43.0758"
echo "x*x*x+3+4*10 0.42312372" | ../build/test_computation
echo "-------------"
echo "x*x*x+3+4*10 | 5.0"
echo "168.0"
echo "x*x*x+3+4*10 5.0" | ../build/test_computation
echo "-------------"
echo "x*x*x+3+4*10 | 8.18791434"
echo "591.934"
echo "x*x*x+3+4*10 8.18791434" | ../build/test_computation
echo "-------------"
echo "x*x*x+3+4*10 | 10.0"
echo "1043.0"
echo "x*x*x+3+4*10 10.0" | ../build/test_computation
echo "-------------"
echo "x*x*x+3+4*10 | 12.08577276"
echo "1808.32"
echo "x*x*x+3+4*10 12.08577276" | ../build/test_computation
echo "-------------"
echo "x*x*x+3+4*10 | 12.08709931"
echo "1808.9"
echo "x*x*x+3+4*10 12.08709931" | ../build/test_computation
echo "-------------"
echo "x*x*x+3+4*10 | 12.566370614359172"
echo "2027.4"
echo "x*x*x+3+4*10 12.566370614359172" | ../build/test_computation