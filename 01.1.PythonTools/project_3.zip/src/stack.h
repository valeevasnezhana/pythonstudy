#ifndef STACK_H
#define STACK_H

#include "token.h"

struct stack {
    struct stack_node *head;
};

struct stack_node {
    struct token* token_p;
    struct stack_node *next;
};

struct stack *init();

void push(struct stack *stack_inst, struct token* token_pointer);

struct token* pop(struct stack *stack_inst);

struct token* top(struct stack *stack_inst);

void destroy(struct stack *stack_inst);


#endif
