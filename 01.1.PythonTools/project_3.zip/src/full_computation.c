#include <stdlib.h>
#include <stdio.h>
#include "tokenizer.h"
#include "token_computation.h"
#include "shunting_yard_algo.h"
#include "full_computation.h"

int compute_expression_from_string_to_result(char* input_string, double x_value, double* output_value) {
    struct token* output_token_array;
    int output_token_amount;
    process_expression_from_string_to_reverse_polish_array(input_string, &output_token_array, &output_token_amount);
    int has_computation_error = compute_value_for_tokens_at_x(output_token_array, output_token_amount, x_value, output_value);
    if (has_computation_error) {
        return has_computation_error;
    }

    return 0;
}

int create_y_array(double* x_array, double** y_array, int array_size, char* input_string) {
    (*y_array) = (double*) malloc(array_size*sizeof(double));

    int has_computation_error = 0;
    struct token* output_token_array;
    int output_token_amount;
    has_computation_error = process_expression_from_string_to_reverse_polish_array(input_string, &output_token_array, &output_token_amount);
    if (has_computation_error) {
        return has_computation_error;
    }

    double x_value;
    double y_value;
    for (int col_index = 0; col_index < array_size; col_index++) {
        x_value = x_array[col_index];
        has_computation_error = compute_value_for_tokens_at_x(output_token_array, output_token_amount, x_value, &y_value);
        if (has_computation_error) {
            break;
        }
        compute_expression_from_string_to_result(input_string, x_value, &y_value);
        (*y_array)[col_index] = y_value;
    }

    return has_computation_error;
}

int process_expression_from_string_to_reverse_polish_array(char* input_string, struct token** output_token_array, int* output_token_amount) {
    struct token* input_token_array;
    int input_token_amount;
    int input_string_is_incorrect = create_token_array(input_string, &input_token_array, &input_token_amount);
//    printf("\nALL TOKENS:\n");
//    for (int i = 0; i < input_token_amount; i++) {
//        printf("[%d, %d]: %s\n", i, input_token_array[i].type, input_token_array[i].string_value);
//    }
    if (input_string_is_incorrect) {
        return input_string_is_incorrect;
    }

    int input_tokens_are_incorrect = apply_shunting_yard_algo(input_token_array, input_token_amount, output_token_array, output_token_amount);
    if (input_tokens_are_incorrect) {
        return input_tokens_are_incorrect;
    }

    return 0;
}