from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.utils import executor

import os


bot = Bot(token=os.getenv('TOKEN'))
disp = Dispatcher(bot)


@disp.message_handler()
async def potat_send(message: types.Message):
    if message.text == "/help":
        await message.reply("Помоги себе сам")
    else:
        await message.reply("Я простой потат и не знаю, как жить ету жизню")


executor.start_polling(disp, skip_updates=True)
