from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.utils import executor
from cat_project import get_cat_info, get_breed_info

import os

bot = Bot(token=os.getenv('TOKEN'))
disp = Dispatcher(bot)


@disp.message_handler()
async def potat_send(message: types.Message):
    text_str = message.text
    if text_str == "/help":
        helper_string = "- Чтобы найти информацию о коте, введите:\n\tнайди кота [имя кота]\n" \
                        "Пример запроса:\n" \
                        "Найди кота Лулу\n"\
                        "Пример ответа:\nимя: Лулу\n"\
                        "описание: Наглый пожиратель с мордой, похожей на дно пластиковой бутылки\n" \
                        "порода: Манчкин"
        await message.reply(helper_string)
    elif text_str.lower().startswith("найди кота "):
        cat_name = message.text[11:]
        await message.reply(get_cat_info(cat_name))
    elif text_str.lower().startswith("найди породу "):
        breed_name = message.text[13:]
        await message.reply(get_breed_info(breed_name))
    else:
        await message.reply("Я простой потат и не знаю, как жить ету жизню")


executor.start_polling(disp, skip_updates=True)
