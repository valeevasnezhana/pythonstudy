#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "shared.h"

int get_file_size_in_bytes(FILE *input_file_pointer) {
    fseek(input_file_pointer, 0L, SEEK_END);
    long file_size_in_bytes = ftell(input_file_pointer);
    rewind(input_file_pointer);
    return file_size_in_bytes;
}

int create_chosen_record_amount(int row_amount_option, int real_record_amount) {
    int chosen_record_amount;
    if (row_amount_option == -1) {
        chosen_record_amount = real_record_amount;
    } else {
        if (row_amount_option < real_record_amount) {
            chosen_record_amount = row_amount_option;
        } else {
            chosen_record_amount = real_record_amount;
        }
    }
    return chosen_record_amount;
}

char* get_file_path_for_table(t_table_option table_option) {
    char* output_value = NULL;
    if (table_option == MODULES) {
        output_value = "../edited_databases/master_modules.db";
    } else if (table_option == LEVELS) {
        output_value = "../edited_databases/master_levels.db";
    } else if (table_option == EVENTS) {
        output_value = "../edited_databases/master_status_events.db";
    }
    return output_value;
}

void close_if_not_null(FILE* file_pointer) {
    if (file_pointer != NULL) {
        fclose(file_pointer);
    }
}