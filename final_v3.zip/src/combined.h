#ifndef COMBINED_H
#define COMBINED_H

#include <dirent.h>
#include "menu_options.h"
#include "modules.h"
#include "levels.h"
#include "events.h"

int display_all_active_module_records_from_file();

#endif
