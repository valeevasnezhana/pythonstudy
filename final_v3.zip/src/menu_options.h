#ifndef MENU_OPTION_H
#define MENU_OPTION_H

typedef enum top_menu_option_raw {
    SELECT = 1,
    INSERT = 2,
    UPDATE = 3,
    DELETE = 4,
    GET_ALL_ACTIVE_ADDITIONAL_MODULES = 5,
    DELETE_MODULES_BY_IDS = 6,
    SET_PROTECTED_MODE_FOR_MODULE_BY_ID = 7,
    MOVE_MODULE = 8,
    SET_PROTECTED_FLAG_FOR_LEVEL_BY_ID = 9
} t_top_menu_option;

typedef enum table_option_raw {
    MODULES = 1,
    LEVELS = 2,
    EVENTS = 3
} t_table_option;

#endif
