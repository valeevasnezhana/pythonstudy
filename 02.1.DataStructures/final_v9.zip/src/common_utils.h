#ifndef COMMON_UTILS_H
#define COMMON_UTILS_H

#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "menu_options.h"

typedef enum update_status_raw {
    UPDATE_INPUT_ERROR = 1,
    UPDATE_ID_NOT_FOUND_ERROR = 2,
    UPDATE_INTERNAL_ERROR = 3,
    UPDATE_SUCCESS = 4,
} t_update_status;

typedef enum delete_status_raw {
    DELETE_ID_NOT_FOUND_ERROR = 1,
    DELETE_INTERNAL_ERROR = 2,
    DELETE_SUCCESS = 3,
} t_delete_status;

int get_file_size_in_bytes(FILE *input_file_pointer);

int create_chosen_record_amount(int row_amount_option, int real_record_amount);

char* get_file_path_for_table(t_table_option table_option);

void close_if_not_null(FILE* file_pointer);

#endif
