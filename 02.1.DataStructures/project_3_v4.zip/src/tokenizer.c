#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stack.h"
#include "tokenizer.h"

void save_token_if_needed(char* input_string, struct token token_array[], int* current_token_index, enum t_token_type current_token_type, int current_token_start, int input_index) {
    int token_length = input_index - current_token_start;
    if (token_length > 0 && current_token_type != UNDEFINED) {
        char* token_data = (char*) malloc(token_length+1 * sizeof(char));
        memcpy(token_data, &input_string[current_token_start], token_length);
        token_data[token_length] = '\0';
        token_array[*current_token_index].string_value = token_data;
        token_array[*current_token_index].type = current_token_type;
        (*current_token_index)++;
    }
}

int create_token_array(char* input_string, struct token** token_array, int* token_amount) {
    (*token_array) = (struct token*) malloc (1024 * sizeof(struct token));

    int incorrect_input = 0;
    int input_index = 0;
    int current_token_index = 0;
    int current_token_start = 0;
    int current_number_dot_amount = 0;
    enum t_token_type current_token_type = UNDEFINED;
    enum t_token_type previous_token_type = UNDEFINED;
    while (incorrect_input == 0 && input_string[input_index] != '\0') {
        char current_char = input_string[input_index];
//        printf("[%d, %d, %d]: '%c'\n", current_token_start, input_index, current_token_type, current_char);
        int is_number = (current_char >= '0' && current_char <= '9') || current_char == 'x';
        int is_letter = current_char >= 'a' && current_char <= 'z';
        int is_math_operation = current_char == '+' || current_char == '-' || current_char == '/' || current_char == '*';
        if (current_token_type == FUNCTION && is_letter) {
            input_index++;
            continue;
        } else if (current_token_type == NUMBER) {
            if (is_number) {
                input_index++;
                continue;
            } else if (current_char == '.') {
                if (current_number_dot_amount == 0) {
                    current_number_dot_amount = 1;
                    input_index++;
                    continue;
                } else {
                    incorrect_input = 1;
                    break;
                }
            }
        }

        save_token_if_needed(input_string, *token_array, &current_token_index, current_token_type, current_token_start, input_index);

        current_number_dot_amount = 0;
        current_token_start = input_index;
        if (current_token_type != UNDEFINED) {
            previous_token_type = current_token_type;
        }
        if (is_number) {
            current_token_type = NUMBER;
        } else if (is_math_operation) {
            if (previous_token_type == NUMBER) {
                current_token_type = BINARY_OPERATION;
            } else if (current_char == '-') {
                current_token_type = UNARY_OPERATION;
            } else {
                incorrect_input = 1;
                break;
            }
        } else if (is_letter) {
            current_token_type = FUNCTION;
        } else if (current_char == '(') {
            current_token_type = LEFT_BRACE;
        } else if (current_char == ')') {
            current_token_type = RIGHT_BRACE;
        } else if (current_char == ' ') {
            current_token_type = UNDEFINED;
        }
        input_index++;
    }
    save_token_if_needed(input_string, *token_array, &current_token_index, current_token_type, current_token_start, input_index);

    *token_amount = current_token_index;
    return incorrect_input;
}
