#include "graph.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void create_x_array(double** x_array, int* array_size) {
    int const col_amount = 80;
    double const x_min = 0, x_max = 4 * M_PI;
    double const step_x = (x_max - x_min) / (col_amount - 1);

    *x_array = (double*) malloc(col_amount*sizeof(double));
    *array_size = col_amount;

    for (int col_index = 0; col_index < col_amount; col_index++) {
        double x = x_min + col_index * step_x;
        (*x_array)[col_index] = x;
    }
}

void print_result(const double* y_array){
    int const row_amount = 25, col_amount = 80;
    double const y_min = -1, y_max = 1;

    for (int row_index = 0; row_index < row_amount; row_index++) {
        for (int col_index = 0; col_index < col_amount; col_index++) {
            double y = y_array[col_index];
            int expected_index = round((row_amount - 1) * (y - y_min) / (y_max - y_min));
            if (row_index == expected_index) {
                printf(DOT);
            } else {
                printf(VOID);
            }
        }
        if (row_index < (row_amount - 1)) {
            printf("\n");
        }
    }
}
