#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "token.h"
#include "numeric_stack.h"
#include "token_computation.h"

//void print_numeric_stack_state(struct numeric_stack* operator_stack) {
//    struct numeric_stack_node* numeric_current_node = operator_stack->head;
//    printf("# Stack: ");
//    while (numeric_current_node != NULL) {
//        printf("[%.3lf]", numeric_current_node->value);
//        numeric_current_node = numeric_current_node->next;
//    }
//    printf("\n");
//}

int compute_value_for_tokens_at_x(struct token* token_array, int token_amount, double x_value, double* output_value) {
    int has_computation_error = 0;

    struct numeric_stack_node* top_node;
    struct numeric_stack_node* first_node;
    struct numeric_stack_node* second_node;
    struct numeric_stack* computation_stack = init_numeric();
    for (int token_index = 0; token_index < token_amount; token_index++) {
        struct token* current_token = &(token_array[token_index]);
//        printf("+++ [%d, %d]: %s\n", token_index, current_token->type, current_token->string_value);

        if (current_token->type == NUMBER) {
            if (strcmp(current_token->string_value, "x") == 0) {
                push_numeric(computation_stack, x_value);
            } else {
                double parsed_numeric_value;
                int amount_parsed = sscanf(current_token->string_value, "%lf", &parsed_numeric_value);
                if (amount_parsed == 0) {
                    has_computation_error = 1;
                    break;
                } else {
                    push_numeric(computation_stack, parsed_numeric_value);
                }
            }
        } else if (current_token->type == UNARY_OPERATION) {
            top_node = pop_numeric(computation_stack);
            if (top_node == NULL) {
                has_computation_error = 1;
                break;
            } else {
                double top_value = top_node->value;
                free(top_node);
                push_numeric(computation_stack, top_value*(-1));
            }
        } else if (current_token->type == FUNCTION) {
            top_node = pop_numeric(computation_stack);
            if (top_node == NULL) {
                has_computation_error = 1;
                break;
            } else {
                double top_value = top_node->value;
                free(top_node);
                double computed_expression_value;
                if (strcmp(current_token->string_value, "sin") == 0) {
                    computed_expression_value = sin(top_value);
                } else if (strcmp(current_token->string_value, "cos") == 0) {
                    computed_expression_value = cos(top_value);
                } else if (strcmp(current_token->string_value, "tan") == 0) {
                    double nom_value = sin(top_value);
                    double denom_value = cos(top_value);
                    if (denom_value == 0) {
                        has_computation_error = 1;
                        break;
                    }
                    computed_expression_value = nom_value / denom_value;
                } else if (strcmp(current_token->string_value, "ctg") == 0) {
                    double nom_value = cos(top_value);
                    double denom_value = sin(top_value);
                    if (denom_value == 0) {
                        has_computation_error = 1;
                        break;
                    }
                    computed_expression_value = nom_value / denom_value;
                } else if (strcmp(current_token->string_value, "sqrt") == 0) {
                    computed_expression_value = sqrt(top_value);
                } else if (strcmp(current_token->string_value, "log") == 0 || strcmp(current_token->string_value, "ln") == 0) {
                    computed_expression_value = log(top_value);
                } else {
                    has_computation_error = 1;
                    break;
                }
                push_numeric(computation_stack, computed_expression_value);
            }
        } else if (current_token->type == BINARY_OPERATION) {
            first_node = pop_numeric(computation_stack);
            second_node = pop_numeric(computation_stack);
            if (first_node == NULL || second_node == NULL) {
                if (first_node != NULL) {
                    free(first_node);
                }
                if (second_node != NULL) {
                    free(second_node);
                }
                has_computation_error = 1;
                break;
            } else {
                double left_value = second_node->value;
                double right_value = first_node->value;
                free(first_node);
                free(second_node);
                double computed_binary_value;
                if (strcmp(current_token->string_value, "+") == 0) {
                    computed_binary_value = left_value+right_value;
                } else if (strcmp(current_token->string_value, "-") == 0) {
                    computed_binary_value = left_value-right_value;
                } else if (strcmp(current_token->string_value, "/") == 0) {
                    if (fabs(right_value - 0.0) < 0.0000001) {
                        has_computation_error = 1;
                        break;
                    } else {
                        computed_binary_value = left_value / right_value;
                    }
                } else if (strcmp(current_token->string_value, "*") == 0) {
                    computed_binary_value = left_value * right_value;
                } else {
                    has_computation_error = 1;
                    break;
                }
                push_numeric(computation_stack, computed_binary_value);
            }
        }
//        print_numeric_stack_state(computation_stack);
    }

    top_node = pop_numeric(computation_stack);
    if (top_node == NULL) {
        has_computation_error = 1;
    } else {
        *output_value = top_node->value;
        free(top_node);
    }

    if (top_numeric(computation_stack) != NULL) {
        has_computation_error = 1;
    }
    destroy_numeric(computation_stack);

    return has_computation_error;
}
