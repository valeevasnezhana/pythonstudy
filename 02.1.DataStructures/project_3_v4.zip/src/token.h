#ifndef TOKEN_H
#define TOKEN_H

enum t_token_type{
    FUNCTION = 0,
    NUMBER = 1,
    BINARY_OPERATION = 2,
    UNARY_OPERATION = 3,
    LEFT_BRACE = 4,
    RIGHT_BRACE = 5,
    UNDEFINED = 6
};

struct token {
    enum t_token_type type;
    char* string_value;
};

#endif