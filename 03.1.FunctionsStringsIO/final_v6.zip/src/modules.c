#include <dirent.h>
#include <stdio.h>
#include "modules.h"
#include "common_utils.h"

int read_module_record_from_file_at_index(FILE *file_pointer, int record_index, t_module_record* record) {
    int return_code = 0;
    int read_obj_amount = 0;

    int offset = record_index * sizeof(t_module_record);
    fseek(file_pointer, offset, SEEK_SET);
    read_obj_amount += fread(record, sizeof(t_module_record), 1, file_pointer);
    rewind(file_pointer);

    if (read_obj_amount != 1) {
        return_code = 1;
    }
    return return_code;
}

int write_module_record_to_file_at_index(FILE *file_pointer, int record_index, t_module_record* record) {
    int return_code = 0;

    int written_obj_amount = 0;
    int offset = record_index * sizeof(t_module_record);
    fseek(file_pointer, offset, SEEK_SET);
    written_obj_amount = fwrite(record, sizeof(t_module_record), 1, file_pointer);
    fflush(file_pointer);
    rewind(file_pointer);

    if (written_obj_amount != 1) {
        return_code = 1;
    }
    return return_code;
}

int append_new_module_record_to_file(char file_path[1024], t_module_record* new_record) {
    int return_code = 0;

    FILE *output_file_pointer = fopen(file_path, "a+b");
    if (output_file_pointer == NULL) {
        return_code = 1;
    } else {
        print_module_record(new_record);
        int written_obj_amount = fwrite(new_record, sizeof(t_module_record), 1, output_file_pointer);
        fflush(output_file_pointer);
        fclose(output_file_pointer);
        if (written_obj_amount != 1) {
            return_code = 1;
        }
    }

    return return_code;
}

t_delete_status delete_module_record_with_id(FILE *file_pointer, int id) {
    int error_amount = 0;
    int record_was_found = 0;
    t_delete_status status = DELETE_SUCCESS;

    int initial_record_amount = get_module_record_amount(file_pointer);
    int write_record_index = 0;
    t_module_record current_record;

    for (int read_record_index = 0; read_record_index < initial_record_amount; read_record_index++) {
        error_amount += read_module_record_from_file_at_index(file_pointer, read_record_index, &current_record);
        if (error_amount > 0) {
            status = DELETE_INTERNAL_ERROR;
            break;
        }
        if (current_record.id == id) {
            record_was_found = 1;
            continue;
        }
        write_module_record_to_file_at_index(file_pointer, write_record_index, &current_record);
        write_record_index++;
    }
    if (record_was_found == 0 && status == DELETE_SUCCESS) {
        status = DELETE_ID_NOT_FOUND_ERROR;
    }
    return status;
}

int get_module_record_amount(FILE *input_file_pointer) {
    long file_size_in_bytes = get_file_size_in_bytes(input_file_pointer);
    int record_amount = (int) file_size_in_bytes / sizeof(t_module_record);
    return record_amount;
}

int display_module_records_from_file(FILE *input_file_pointer, int record_amount) {
    t_module_record record;
    int has_error = 0;
    for (int record_index = 0; record_index < record_amount; record_index++) {
        int has_error = read_module_record_from_file_at_index(input_file_pointer, record_index, &record);
        if (has_error == 1) {
            break;
        } else {
            print_module_record(&record);
        }
    }
    return has_error;
}

void print_module_record(t_module_record* record) {
    if (record != NULL) {
        printf(
            "%d \"%s\" %d %d %d\n",
            record->id,
            record->name,
            record->memory_level_index,
            record->cell_index,
            record->removal_flag
        );
    }
}

int scan_module_record_from_console(t_module_record* record) {
    int received_values = 0;
    printf("id=");
    received_values = scanf("%d", &(record->id));
    if (received_values != 1) {
        return 1;
    }
    printf("name=");
    received_values = scanf("%30s", record->name);
    if (received_values != 1) {
        return 1;
    }
    printf("memory_level_index=");
    received_values = scanf("%d", &(record->memory_level_index));
    if (received_values != 1) {
        return 1;
    }
    printf("cell_index=");
    received_values = scanf("%d", &(record->cell_index));
    if (received_values != 1) {
        return 1;
    }
    printf("removal_flag=");
    received_values = scanf("%d", &(record->removal_flag));
    if (received_values != 1) {
        return 1;
    }
    return 0;
}

int scan_and_append_new_module_record_to_file(char file_path[1024]) {
    int return_code = 0;
    t_module_record new_record;
    int scan_has_error = scan_module_record_from_console(&new_record);
    if (scan_has_error) {
        return_code = 1;
    } else {
        int append_has_error = append_new_module_record_to_file(file_path, &new_record);
        if (append_has_error) {
            return_code = 1;
        }
    }
    return return_code;
}

t_update_status scan_and_update_module_record_with_id(FILE *file_pointer) {
    t_update_status update_status = UPDATE_SUCCESS;
    t_module_record new_record, current_record;
    int record_was_found = 0;
    int scan_has_error = scan_module_record_from_console(&new_record);
    if (scan_has_error || file_pointer == NULL) {
        update_status = UPDATE_INPUT_ERROR;
    } else {
        int record_amount = get_module_record_amount(file_pointer);
        for (int record_index = 0; record_index < record_amount; record_index++) {
            int has_io_error = read_module_record_from_file_at_index(file_pointer, record_index, &current_record);
            if (has_io_error) {
                update_status = UPDATE_INTERNAL_ERROR;
                break;
            }
            if (current_record.id != new_record.id) {
                continue;
            }
            record_was_found = 1;
            has_io_error = write_module_record_to_file_at_index(file_pointer, record_index, &new_record);
            if (has_io_error) {
                update_status = UPDATE_INTERNAL_ERROR;
            }
            break;
        }
    }
    if (record_was_found == 0 && update_status == UPDATE_SUCCESS) {
        update_status = UPDATE_ID_NOT_FOUND_ERROR;
    }
    return update_status;
}

int find_module_by_id(FILE *file_pointer, int id, t_module_record* record, int* module_index) {
    int error_amount = 0;
    int module_was_found = 0;
    t_module_record current_record;
    int total_module_amount = get_module_record_amount(file_pointer);
    for (int current_index = 0; current_index < total_module_amount; current_index++) {
        error_amount += read_module_record_from_file_at_index(file_pointer, current_index, &current_record);
        if (error_amount > 0) {
            break;
        }
        if (current_record.id == id) {
            (*record) = current_record;
            (*module_index) = current_index;
            module_was_found = 1;
            break;
        }
    }
    return module_was_found;
}
