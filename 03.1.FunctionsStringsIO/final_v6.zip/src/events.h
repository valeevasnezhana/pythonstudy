#ifndef EVENTS_H
#define EVENTS_H

#include "common_utils.h"

typedef struct event_record_raw {
    int event_id;
    int module_id;
    int new_module_status;
    char status_change_date[11];
    char status_change_time[9];
} t_event_record;

typedef struct event_change_datetime_raw {
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int second;
} t_event_change_datetime;

int read_event_record_from_file_at_index(FILE *file_pointer, int record_index, t_event_record* record);

int write_event_record_to_file_at_index(FILE *file_pointer, int record_index, t_event_record* record);

int append_new_event_record_to_file(char file_path[1024], t_event_record* new_record);

t_delete_status delete_event_record_with_id(FILE *file_pointer, int id);

int get_event_record_amount(FILE *input_file_pointer);

int display_event_records_from_file(FILE *input_file_pointer, int record_amount);

void print_event_record(t_event_record* record);

int scan_event_record_from_console(t_event_record* record);

int scan_and_append_new_event_record_to_file(char file_path[1024]);

t_update_status scan_and_update_event_record_with_id(FILE *file_pointer);

int extract_datetime_from_event(t_event_record* event_record, t_event_change_datetime* datetime);

int left_datetime_is_less_than_right(t_event_change_datetime* left_datetime, t_event_change_datetime* right_datetime);

#endif
