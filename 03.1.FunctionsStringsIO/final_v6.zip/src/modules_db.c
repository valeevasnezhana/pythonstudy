#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "modules.h"
#include "levels.h"
#include "events.h"
#include "common_utils.h"
#include "shared.h"
#include "menu_options.h"

void display_top_menu();

void display_table_menu();

int launch_table_option_loop_and_get_option(t_table_option* table_option);

void process_select_option();

void process_insert_option();

void process_update_option();

void process_delete_option();

void process_option_delete_modules_by_ids();

void launch_top_option_loop();

int main() {
    launch_top_option_loop();
    return 0;
}

void display_top_menu() {
    printf("Please choose one operation:\n");
    printf("1. SELECT\n");
    printf("2. INSERT\n");
    printf("3. UPDATE\n");
    printf("4. DELETE\n");
    printf("5. Get all active additional modules (last module status is 1)\n");
    printf("6. Delete modules by ids\n");
    printf("7. Set protected mode for module by id\n");
    printf("8. Move module by id to specified memory level and cell\n");
    printf("9. Set protection flag of the specified memory level\n");
    printf("(Enter -1 for exit)\n");
}

void display_table_menu() {
    printf("Please choose a table:\n");
    printf("1. Modules\n");
    printf("2. Levels\n");
    printf("3. Status events\n");
}

int launch_table_option_loop_and_get_option(t_table_option* table_option) {
    int current_iteration = 0;
    int raw_table_option;
    while (current_iteration < 10) {
        current_iteration++;

        display_table_menu();
        scanf("%d", &raw_table_option);
        if (raw_table_option >= MODULES && raw_table_option <= EVENTS) {
            *table_option = raw_table_option;
            break;
        } else {
            printf("You have entered incorrect option: %d\n", raw_table_option);
        }
        printf("-----\n\n");
    }
    return 0;
}

void process_select_option() {
    t_table_option table_option;
    int row_amount_option = -1;
    launch_table_option_loop_and_get_option(&table_option);
    printf("Insert the number of records or insert -1 to output all of them:\n");
    scanf("%d", &row_amount_option);
    if (row_amount_option <= 0) {
        row_amount_option = -1;
    }

    char* table_file_path = get_file_path_for_table(table_option);
    FILE* input_file_pointer = fopen(table_file_path, "r+b");
    if (input_file_pointer == NULL) {
        printf("Database file not found, select aborted. Path: %s", table_file_path);
        return;
    }

    int real_record_amount;
    int chosen_record_amount;
    if (table_option == MODULES) {
        real_record_amount = get_module_record_amount(input_file_pointer);
        chosen_record_amount = create_chosen_record_amount(row_amount_option, real_record_amount);
        display_module_records_from_file(input_file_pointer, chosen_record_amount);
    } else if (table_option == LEVELS) {
        real_record_amount = get_level_record_amount(input_file_pointer);
        chosen_record_amount = create_chosen_record_amount(row_amount_option, real_record_amount);
        display_level_records_from_file(input_file_pointer, chosen_record_amount);
    } else if (table_option == EVENTS) {
        real_record_amount = get_event_record_amount(input_file_pointer);
        chosen_record_amount = create_chosen_record_amount(row_amount_option, real_record_amount);
        display_event_records_from_file(input_file_pointer, chosen_record_amount);
    }
    fclose(input_file_pointer);
}

void process_insert_option() {
    t_table_option table_option;
    launch_table_option_loop_and_get_option(&table_option);

    int scan_has_error = 0;
    char* table_file_path = get_file_path_for_table(table_option);
    printf("Enter data for insert:\n");
    if (table_option == MODULES) {
        scan_has_error = scan_and_append_new_module_record_to_file(table_file_path);
    } else if (table_option == LEVELS) {
        scan_has_error = scan_and_append_new_level_record_to_file(table_file_path);
    } else if (table_option == EVENTS) {
        scan_has_error = scan_and_append_new_event_record_to_file(table_file_path);
    }
    if (scan_has_error) {
        printf("You have entered data incorrectly, insert aborted\n");
    } else {
        printf("Data inserted successfully\n");
    }
}

void process_update_option() {
    t_table_option table_option;
    launch_table_option_loop_and_get_option(&table_option);
    char* table_file_path = get_file_path_for_table(table_option);
    FILE* input_file_pointer = fopen(table_file_path, "r+b");
    if (input_file_pointer == NULL) {
        printf("Database file not found, update aborted. Path: %s", table_file_path);
        return;
    }
    t_update_status update_status;
    printf("Enter data for update:\n");
    if (table_option == MODULES) {
        update_status = scan_and_update_module_record_with_id(input_file_pointer);
    } else if (table_option == LEVELS) {
        update_status = scan_and_update_level_record_with_id(input_file_pointer);
    } else if (table_option == EVENTS) {
        update_status = scan_and_update_event_record_with_id(input_file_pointer);
    } else {
        update_status = UPDATE_INTERNAL_ERROR;
    }
    if (update_status == UPDATE_SUCCESS) {
        printf("Updated successfully\n");
    } else if (update_status == UPDATE_INTERNAL_ERROR) {
        printf("Internal error occurred\n");
    } else if (update_status == UPDATE_ID_NOT_FOUND_ERROR) {
        printf("Such id not found, update aborted\n");
    } else if (update_status == UPDATE_INPUT_ERROR) {
        printf("You have entered data incorrectly, update aborted\n");
    }
    fclose(input_file_pointer);
}

void process_delete_option() {
    t_table_option table_option;
    launch_table_option_loop_and_get_option(&table_option);

    char* table_file_path = get_file_path_for_table(table_option);
    FILE* input_file_pointer = fopen(table_file_path, "r+b");
    if (input_file_pointer == NULL) {
        printf("Database file not found, delete aborted. File path: %s", table_file_path);
        return;
    }

    int input_id;
    printf("Enter id for record you want to delete:\n");
    scanf("%d", &input_id);

    t_delete_status delete_status;
    if (table_option == MODULES) {
        delete_status = delete_module_record_with_id(input_file_pointer, input_id);
    } else if (table_option == LEVELS) {
        delete_status = delete_level_record_with_memory_level_index(input_file_pointer, input_id);
    } else if (table_option == EVENTS) {
        delete_status = delete_event_record_with_id(input_file_pointer, input_id);
    } else {
        delete_status = DELETE_INTERNAL_ERROR;
    }
    if (delete_status == DELETE_SUCCESS) {
        printf("Module deleted successfully\n");
    } else if (delete_status == DELETE_INTERNAL_ERROR) {
        printf("Internal error occurred\n");
    } else if (delete_status == DELETE_ID_NOT_FOUND_ERROR) {
        printf("Module with id %d not found, delete aborted\n", input_id);
    }
    fclose(input_file_pointer);
}

void process_option_delete_modules_by_ids() {
    char* table_file_path = get_file_path_for_table(MODULES);
    FILE* input_file_pointer = fopen(table_file_path, "r+b");
    if (input_file_pointer == NULL) {
        printf("Database file not found, delete aborted. File path: %s", table_file_path);
        return;
    }
    int error_amount = 0;
    int module_amount_for_deletion;
    printf("Please input amount of modules you want to delete:\n");
    scanf("%d", &module_amount_for_deletion);
    printf("Please input the ids of the deleting modules: ");
    int module_id;
    int* module_id_array = (int*) malloc(module_amount_for_deletion*sizeof(int));
    for (int index = 0; index < module_amount_for_deletion; index++) {
        scanf("%d", &(module_id_array[index]));
    }
    t_module_record record;
    int module_index;
    for (int index = 0; index < module_amount_for_deletion; index++) {
        module_id = module_id_array[index];
        int module_was_found = find_module_by_id(input_file_pointer, module_id, &record, &module_index);
        if (module_was_found) {
            record.removal_flag = 1;
            error_amount += write_module_record_to_file_at_index(input_file_pointer, module_index, &record);
        }
        if (error_amount > 0) {
            break;
        }
    }
    if (error_amount > 0) {
        printf("Error occurred when deleting some of the modules\n");
    } else {
        printf("Ids were deleted successsfully\n");
    }
    free(module_id_array);
    fclose(input_file_pointer);
}

void process_option_set_protected_mode_for_module_by_id() {
    int error_amount = 0;
    char* table_file_path = get_file_path_for_table(EVENTS);
    int module_id;
    printf("Please input module id:\n");
    scanf("%d", &module_id);

    t_event_record first_step_event;
    first_step_event.event_id = module_id+100+1;
    first_step_event.module_id = module_id;
    first_step_event.new_module_status = 0;
    strcpy(first_step_event.status_change_date, "2023:03:23");
    strcpy(first_step_event.status_change_time, "10:00:00");
    error_amount += append_new_event_record_to_file(table_file_path, &first_step_event);

    t_event_record second_step_event;
    second_step_event.event_id = module_id+100+2;
    second_step_event.module_id = module_id;
    second_step_event.new_module_status = 1;
    strcpy(second_step_event.status_change_date, "2023:03:23");
    strcpy(second_step_event.status_change_time, "10:00:00");
    error_amount += append_new_event_record_to_file(table_file_path, &second_step_event);

    t_event_record third_step_event;
    third_step_event.event_id = module_id+100+2;
    third_step_event.module_id = module_id;
    third_step_event.new_module_status = 20;
    strcpy(third_step_event.status_change_date, "2023:03:23");
    strcpy(third_step_event.status_change_time, "10:00:00");
    error_amount += append_new_event_record_to_file(table_file_path, &third_step_event);

    if (error_amount == 0) {
        printf("Module set to protected mode successfully\n");
    } else {
        printf("Error occurred when setting module set to protected mode");
    }
}

void process_option_move_module() {
    char* table_file_path = get_file_path_for_table(MODULES);
    FILE* input_file_pointer = fopen(table_file_path, "r+b");
    if (input_file_pointer == NULL) {
        printf("Database file not found, delete aborted. File path: %s", table_file_path);
        return;
    }
    int error_amount = 0;

    int module_id, new_memory_level_index, new_cell_index;
    printf("Please input module id:\n");
    scanf("%d", &module_id);
    printf("Please input memory level index:\n");
    scanf("%d", &new_memory_level_index);
    printf("Please input cell index:\n");
    scanf("%d", &new_cell_index);

    int module_index;
    t_module_record record;
    int module_was_found = find_module_by_id(input_file_pointer, module_id, &record, &module_index);
    if (module_was_found) {
        record.memory_level_index = new_memory_level_index;
        record.cell_index = new_cell_index;
        error_amount += write_module_record_to_file_at_index(input_file_pointer, module_index, &record);
    } else {
        printf("Such id was not found\n");
    }
    if (error_amount > 0) {
        printf("Error occurred when moving module");
    }
    fclose(input_file_pointer);
}

void process_option_set_protected_flag_for_level_by_id() {
    char* table_file_path = get_file_path_for_table(LEVELS);
    FILE* input_file_pointer = fopen(table_file_path, "r+b");
    if (input_file_pointer == NULL) {
        printf("Database file not found, delete aborted. File path: %s", table_file_path);
        return;
    }
    int error_amount = 0;

    int memory_level_index;
    int new_protection_flag;
    printf("Please input memory level index:\n");
    scanf("%d", &memory_level_index);
    printf("Please input new protection flag value:\n");
    scanf("%d", &new_protection_flag);

    int array_index;
    t_level_record record;
    int level_was_found = find_level_by_memory_level_index(input_file_pointer, memory_level_index, &record, &array_index);
    if (level_was_found) {
        record.protection_flag = new_protection_flag;
        error_amount += write_level_record_to_file_at_index(input_file_pointer, array_index, &record);
        if (error_amount > 0) {
            printf("Error occurred when setting protection flag for level\n");
        } else {
            printf("Successfully set new protection flag for level %d: %d\n", memory_level_index, new_protection_flag);
        }
    } else {
        printf("Such id was not found\n");
    }
    fclose(input_file_pointer);
}

void launch_top_option_loop() {
    int current_iteration = 0;

    int raw_top_option;

    while (current_iteration < 10) {
        current_iteration++;

        display_top_menu();
        scanf("%d", &raw_top_option);
        if (raw_top_option == EXIT_PROGRAM) {
            printf("Exiting database...\n");
            break;
        } else if (raw_top_option == SELECT) {
            process_select_option();
        } else if (raw_top_option == INSERT) {
            process_insert_option();
        } else if (raw_top_option == UPDATE) {
            process_update_option();
        } else if (raw_top_option == DELETE) {
            process_delete_option();
        } else if (raw_top_option == GET_ALL_ACTIVE_ADDITIONAL_MODULES) {
            display_all_active_module_records_from_file();
        } else if (raw_top_option == DELETE_MODULES_BY_IDS) {
            process_option_delete_modules_by_ids();
        } else if (raw_top_option == SET_PROTECTED_MODE_FOR_MODULE_BY_ID) {
            process_option_set_protected_mode_for_module_by_id();
        } else if (raw_top_option == MOVE_MODULE) {
            process_option_move_module();
        } else if (raw_top_option == SET_PROTECTED_FLAG_FOR_LEVEL_BY_ID) {
            process_option_set_protected_flag_for_level_by_id();
        } else {
            printf("You have entered incorrect option: %d\n", raw_top_option);
        }
        printf("-----\n\n");
    }
}
