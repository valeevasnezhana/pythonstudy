rm -rf ../edited_databases
mkdir ../edited_databases
cp ../materials/*.db ../edited_databases
rm -f output_exec
gcc -Wall -Werror -Wextra shared.c modules.c levels.c events.c modules_db.c -o output_exec && ./output_exec