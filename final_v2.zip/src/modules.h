#ifndef MODULES_H
#define MODULES_H

#include "shared.h"

typedef struct module_record_raw {
    int id;
    char name[30];
    int memory_level_index;
    int cell_index;
    int removal_flag;
} t_module_record;

int read_module_record_from_file_at_index(FILE *file_pointer, int record_index, t_module_record* record);

int write_module_record_to_file_at_index(FILE *file_pointer, int record_index, t_module_record* record);

int append_new_module_record_to_file(char file_path[1024], t_module_record* new_record);

t_delete_status delete_module_record_with_id(FILE *file_pointer, int id);

int get_module_record_amount(FILE *input_file_pointer);

int display_module_records_from_file(FILE *input_file_pointer, int record_amount);

void print_module_record(t_module_record* record);

int scan_module_record_from_console(t_module_record* record);

int scan_and_append_new_module_record_to_file(char file_path[1024]);

t_update_status scan_and_update_module_record_with_id(FILE *file_pointer);

#endif
