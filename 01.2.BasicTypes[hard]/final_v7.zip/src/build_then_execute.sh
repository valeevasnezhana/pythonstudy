rm -rf ../edited_databases
mkdir ../edited_databases
cp ../materials/*.db ../edited_databases
make rebuild && ../build/db