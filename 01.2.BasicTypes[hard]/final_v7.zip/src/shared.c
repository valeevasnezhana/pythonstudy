#include <dirent.h>
#include <stdio.h>
#include "common_utils.h"
#include "shared.h"

int display_all_active_module_records_from_file() {
    int error_amount = 0;
    char* module_file_path = get_file_path_for_table(MODULES);
    char* events_file_path = get_file_path_for_table(EVENTS);
    FILE* module_file_pointer = fopen(module_file_path, "rb");
    FILE* event_file_pointer = fopen(events_file_path, "rb");
    if (module_file_pointer == NULL || event_file_pointer == NULL) {
        close_if_not_null(module_file_pointer);
        close_if_not_null(event_file_pointer);
        return 1;
    }
    int module_amount = get_module_record_amount(module_file_pointer);
    int event_amount = get_event_record_amount(event_file_pointer);
    t_module_record module_record;
    t_event_record event_record;
    t_event_change_datetime previous_event_datetime, current_event_datetime;
    for (int module_index = 0; module_index < module_amount; module_index++) {
        int last_status, must_update_status = 0;
        error_amount += read_module_record_from_file_at_index(module_file_pointer, module_index, &module_record);
        last_status = 0;
        for (int event_index = 0; event_index < event_amount; event_index++) {
            error_amount += read_event_record_from_file_at_index(event_file_pointer, event_index, &event_record);
            extract_datetime_from_event(&event_record, &current_event_datetime);
            if (last_status == -1 || left_datetime_is_less_than_right(&previous_event_datetime, &current_event_datetime)) {
                printf("+++ Compared two dates:\n");
                printf("Previous:\n");
                print_event_datetime(&previous_event_datetime);
                printf("Current:\n");
                print_event_datetime(&current_event_datetime);
                must_update_status = 1;
            } else {
                must_update_status = 0;
            }
            previous_event_datetime = current_event_datetime;
            if (must_update_status == 0) {
                continue;
            }
            if (event_record.new_module_status == 1) {
                last_status = 1;
            } else {
                last_status = 0;
            }
        }
        if (error_amount > 0) {
            break;
        }
        if (last_status == 1) {
            print_module_record(&module_record);
        }
    }
    close_if_not_null(module_file_pointer);
    close_if_not_null(event_file_pointer);
    return (error_amount > 0);
}
