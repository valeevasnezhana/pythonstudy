#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stack.h"
#include "numeric_stack.h"
#include "tokenizer.h"
#include "token_computation.h"
#include "full_computation.h"
#include "shunting_yard_algo.h"

int main() {
    char input_string[1024];
    double x_value;
    scanf("%s %lf", input_string, &x_value);
//    printf("Input string: %s\n", input_string);
//    printf("Input x: %lf\n", x_value);

    double output_value;
    int has_computation_error = compute_expression_from_string_to_result(input_string, x_value, &output_value);
    if (has_computation_error) {
        printf("FAIL\n");
    } else {
        printf("%lf\n", output_value);
    }

    return 0;
}
