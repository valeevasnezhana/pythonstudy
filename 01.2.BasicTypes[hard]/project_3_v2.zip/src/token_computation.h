#ifndef TOKEN_COMPUTATION_H
#define TOKEN_COMPUTATION_H

int compute_value_for_tokens_at_x(struct token* token_array, int token_amount, double x_value, double* output_value);

#endif

