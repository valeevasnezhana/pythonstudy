#ifndef NUMERIC_STACK_H
#define NUMERIC_STACK_H

struct numeric_stack {
    struct numeric_stack_node *head;
};

struct numeric_stack_node {
    double value;
    struct numeric_stack_node *next;
};

struct numeric_stack *init_numeric();

void push_numeric(struct numeric_stack *numeric_stack_inst, double value);

struct numeric_stack_node* pop_numeric(struct numeric_stack *numeric_stack_inst);

struct numeric_stack_node* top_numeric(struct numeric_stack *numeric_stack_inst);

void destroy_numeric(struct numeric_stack *numeric_stack_inst);


#endif
