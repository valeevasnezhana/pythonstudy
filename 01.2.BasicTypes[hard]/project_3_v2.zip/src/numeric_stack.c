#include "numeric_stack.h"
#include <stdio.h>
#include <stdlib.h>

struct numeric_stack *init_numeric() {
    struct numeric_stack *t = malloc(sizeof(struct numeric_stack));
    t->head = NULL;
    return t;
}

void push_numeric(struct numeric_stack *numeric_stack_inst, double value) {
    struct numeric_stack_node *head = numeric_stack_inst->head;
    struct numeric_stack_node *new_node = malloc(sizeof(struct numeric_stack_node));
    new_node->next = head;
    new_node->value = value;
    head = new_node;
    numeric_stack_inst->head = head;
}

struct numeric_stack_node* pop_numeric(struct numeric_stack *numeric_stack_inst) {
    struct numeric_stack_node *head = numeric_stack_inst->head;
    struct numeric_stack_node* return_value = NULL;
    if (head != NULL) {
        struct numeric_stack_node *to_remove = head;
        numeric_stack_inst->head = head->next;
        return_value = to_remove;
//        free(to_remove);
    }
    return return_value;
}

struct numeric_stack_node* top_numeric(struct numeric_stack *numeric_stack_inst) {
    struct numeric_stack_node *head = numeric_stack_inst->head;
    struct numeric_stack_node* return_value = NULL;
    if (head != NULL) {
        return_value = head;
    }
    return return_value;
}

void destroy_numeric(struct numeric_stack *numeric_stack_inst) {
    struct numeric_stack_node *head = numeric_stack_inst->head;
    struct numeric_stack_node *tmp = head;

    while (tmp != NULL) {
        head = head->next;
        free(tmp);
        tmp = head;
    }
    free(numeric_stack_inst);
}

