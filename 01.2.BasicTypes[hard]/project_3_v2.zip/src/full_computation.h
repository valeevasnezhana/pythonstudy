#ifndef FULL_COMPUTATION_H
#define FULL_COMPUTATION_H

int process_expression_from_string_to_reverse_polish_array(char* input_string, struct token** output_token_array, int* output_token_amount);
int create_y_array(double* x_array, double** y_array, int array_size, char* input_string);
int compute_expression_from_string_to_result(char* input_string, double x_value, double* output_value);

#endif
