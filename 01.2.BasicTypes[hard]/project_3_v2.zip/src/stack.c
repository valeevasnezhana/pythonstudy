#include "stack.h"
#include <stdio.h>
#include <stdlib.h>

struct stack *init() {
    struct stack *t = malloc(sizeof(struct stack));
    t->head = NULL;
    return t;
}

void push(struct stack *stack_inst, struct token* token_pointer) {
    struct stack_node *head = stack_inst->head;
    struct stack_node *new_node = malloc(sizeof(struct stack_node));
    new_node->next = head;
    new_node->token_p = token_pointer;
    head = new_node;
    stack_inst->head = head;
}

struct token* pop(struct stack *stack_inst) {
    struct stack_node *head = stack_inst->head;
    struct token* return_value = NULL;
    if (head != NULL) {
        struct stack_node *to_remove = head;
        stack_inst->head = head->next;
        return_value = to_remove->token_p;
        free(to_remove);
    }
    return return_value;
}

struct token* top(struct stack *stack_inst) {
    struct stack_node *head = stack_inst->head;
    struct token* return_value = NULL;
    if (head != NULL) {
        return_value = head->token_p;
    }
    return return_value;
}

void destroy(struct stack *stack_inst) {
    struct stack_node *head = stack_inst->head;
    struct stack_node *tmp = head;

    while (tmp != NULL) {
        head = head->next;
        free(tmp);
        tmp = head;
    }
    free(stack_inst);
}

