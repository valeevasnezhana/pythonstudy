#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef LOGGING_CIPHER
#include "log_levels.h"
#include "logger.h"
#endif

enum messages
{
    success,
    incorrect_shift,
    failed_reading,
    failed_writing,
    warning_not_txt,
    incorrect_mode
};


#define LAT_ALPHABET_SIZE 26

void input(FILE *log);
void read_file(char *filename, int *incorrect_input);
void write_add_to_file(char *filename, int *incorrect_input, int file_was_specified);
enum messages path_check(char *filename);
void finder(char *dir_path, int shift, FILE* log);
void caesar(char *caesar_in, char *caesar_out, int shift, FILE *log);
void incorrect_input_checker(int incorrect_input, enum messages, char *str_p, FILE *log);

int main() {
    FILE *log = NULL;
#ifdef LOGGING_CIPHER
    log = log_init("Quest5.txt");
#endif
    input(log);
#ifdef LOGGING_CIPHER
    log_close(log);
#endif
    return 0;
}

void input(FILE *log) {
    int signal = 0;
    int s_res = 0;
    int incorrect_input = 0;
    s_res = scanf("%d", &signal);

    int file_was_specified = 0;
    char filename[256];
    while (signal != -1) {
        if (s_res == 1 && (signal == 1 || signal == 2 || signal == 3)) {
            incorrect_input = 0;
            if (signal == 1) {
                scanf("%s", filename);
                enum messages path_check_result = path_check(filename);
                incorrect_input_checker(0, path_check_result, filename, log);
                read_file(filename, &incorrect_input);
                if (incorrect_input == 0) {
                    file_was_specified = 1;
                }
                incorrect_input_checker(incorrect_input, failed_reading, filename, log);
            } else if (signal == 2) {
                write_add_to_file(filename, &incorrect_input, file_was_specified);
                if (file_was_specified == 1) {
                    read_file(filename, &incorrect_input);
                } else {
                    incorrect_input = 1;
                }
                incorrect_input_checker(incorrect_input, failed_writing, filename, log);
            } else if (signal == 3) {
                int caesar_shift;
                scanf("%s", filename);
                char str_shift[32];
                fgets(str_shift, 32, stdin);
                if (sscanf(str_shift, "%d", &caesar_shift)) {
                    finder(filename, caesar_shift, log);
                } else {
                    incorrect_input_checker(1, incorrect_shift, str_shift, log);
                }
            }
        } else {
            incorrect_input_checker(1, incorrect_mode, "mode must be 1, 2 or 3\0", log);
            scanf("%*[^\n]");
        }
        s_res = scanf("%d", &signal);
    }

}

void incorrect_input_checker(int incorrect_input, enum messages mes, char *str_p, FILE *log) {
    if (incorrect_input) {
        printf("n/a\n");
    }
#ifdef LOGGING_CIPHER
    char log_message[512] = "\0";
    if (mes == incorrect_shift) {
        strcat(log_message, "CAESAR SHIFT is incorrect: ");
        strcat(log_message, str_p);
        logcat(log, log_message, debug);
    } else if (mes == warning_not_txt) {
        strcat(log_message, "FILE is not .txt, can be incorrect: ");
        strcat(log_message, str_p);
        logcat(log, log_message, warning);
    } else if (mes == failed_reading) {
        if (incorrect_input) {
            strcat(log_message, "FAILED to read file: ");
            strcat(log_message, str_p);
            logcat(log, log_message, debug);
        } else {
            strcat(log_message, "SUCCESS to read file: ");
            strcat(log_message, str_p);
            logcat(log, log_message, debug);
        }
    } else if (mes == failed_writing) {
        if (incorrect_input) {
            strcat(log_message, "FAILED adding text to file: ");
            strcat(log_message, str_p);
            logcat(log, log_message, debug);
        } else {
            strcat(log_message, "SUCCESS adding text to file: ");
            strcat(log_message, str_p);
            logcat(log, log_message, debug);
        }
    } else if (mes == incorrect_mode) {
        logcat(log, "INCORRECT mode", debug);
    }
#endif
}


enum messages path_check(char *filename) {
    int sn = strlen(filename);
    enum messages mes = success;
    if (!(filename[sn - 1] == 't' && filename[sn - 2] == 'x' && filename[sn - 3] == 't' && filename[sn - 4] == '.')) {
        mes = warning_not_txt;
    }
    return mes;
}

void read_file(char *filename, int *incorrect_input) {
    FILE *file_pointer = fopen(filename, "r");
    char ch;
    if (file_pointer != NULL) {
        ch = fgetc(file_pointer);
        if (ch != EOF) {
            while (ch != EOF) {
                putchar(ch);
                ch = fgetc(file_pointer);
            }
            putchar('\n');
        } else {
            *incorrect_input = 0;
            printf("n/a\n");
        }
    } else {
        *incorrect_input = 1;
    }
    if (file_pointer != NULL) {
        fclose(file_pointer);
    }
}

void write_add_to_file(char *filename, int *incorrect_input, int file_was_specified) {
    char symbol, symbol2;
    if (*incorrect_input != 1 && file_was_specified == 1) {
        FILE *file_pointer = fopen(filename, "a");
        if (file_pointer != NULL) {
            symbol2 = getchar();
            while ((symbol = getchar()) != '\n') {
                fputc(symbol, file_pointer);
            }
        } else {
            *incorrect_input = 1;
            symbol2 = getchar();
            symbol2 = ' ';
            while (symbol2 != '\n') {
                symbol2 = getchar();
            }
        }
        fclose(file_pointer);
    } else {
        symbol2 = getchar();
        symbol2 = ' ';
        while (symbol2 != '\n') {
            symbol2 = getchar();
        }
    }
}

void finder(char *dir_path, int shift, FILE* log) {
    char *pointer1, *pointer2, *caesar_in, *clean_in;
    char dir_path_cp[256], dir_path_cp1[256];
    DIR *dr;
    int rn;
    struct dirent *dir_read;
    dr = opendir(dir_path);
    if (dr != NULL) {
        while ((dir_read = readdir(dr)) != NULL) {
            pointer1 = strtok(dir_read->d_name, ".");
            pointer2 = strtok(NULL, ".");
            if (pointer2 != NULL) {
                rn = strcmp(pointer2, "c");
                if (rn == 0) {
                    caesar_in = strcat(pointer1, ".c");
                    strcpy(dir_path_cp, dir_path);
                    caesar_in = strcat(dir_path_cp, caesar_in);
                    caesar(caesar_in, pointer1, shift, log);
                    remove(caesar_in);
                    rename(pointer1, caesar_in);
                }
                rn = strcmp(pointer2, "h");
                if (rn == 0) {
                    clean_in = strcat(pointer1, ".h");
                    strcpy(dir_path_cp1, dir_path);
                    clean_in = strcat(dir_path_cp1, clean_in);
                    FILE *cl_aim = fopen(clean_in, "wb");
                    fclose(cl_aim);
                }
            }
        }
        closedir(dr);
    } else {
        printf("n/a\n");
    }
}

void caesar(char *caesar_in, char *caesar_out, int shift, FILE *log) {
    FILE *file1, *file2;
    file1 = fopen(caesar_in, "r");
    file2 = fopen(caesar_out, "w");
    char symbol;
    symbol = getc(file1);
    while (symbol != EOF) {
        if (symbol >= 'A' && symbol <= 'Z') {
            symbol = 'A' + (symbol - 'A' + shift) % LAT_ALPHABET_SIZE;
        } else if (symbol >= 'a' && symbol <= 'z') {
            symbol = 'a' + (symbol - 'a' + shift) % LAT_ALPHABET_SIZE;
        }
        fputc(symbol, file2);
        symbol = getc(file1);
    }
#ifdef LOGGING_CIPHER
    char log_message[128] = "\0";
    strcat(log_message, "file encoded: ");
    strcat(log_message, caesar_in);
    logcat(log, log_message, info);
#endif
    fclose(file1);
    fclose(file2);
}