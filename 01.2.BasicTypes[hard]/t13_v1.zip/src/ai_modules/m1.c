#jodmvef "n1.i"


wpje n1_g1()
{
    qsjoug("UFTU N1");
}
