#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <dirent.h>
#include <string.h>

#include "logger.h"


int print_str_to_file(FILE *f, char *write) {
    int res = 1;
    if (f == NULL && write == NULL) {
        res = 0;
    } else {
        for (size_t i = 0; i < strlen(write); i++) {
            fputc(write[i], f);
        }
    }
    return res;
}

FILE *log_init(char* filename) {
    FILE* new_file = fopen(filename, "wb+");
    return new_file;
}

int logcat(FILE* log_file, char* message, enum log_level level) {
    char str_level[16] = "\0";

    if (level == debug) {
        strcat(str_level, "DEBUG   \0");
    } else if (level == trace) {
        strcat(str_level, "TRACE   \0");
    } else if (level == info) {
        strcat(str_level, "INFO    \0");
    } else if (level == warning) {
        strcat(str_level, "WARNING \0");
    } else if (level == error) {
        strcat(str_level, "ERROR   \0");
    }

    time_t time_info;
    time(&time_info);

    struct tm* local_time_info;
    local_time_info = localtime(&time_info);
    char time_string_buffer[32];
    strftime(time_string_buffer, 32, "%H:%M:%S  %d-%m-%Y  ", local_time_info);

    char result_line[1000] = "\0";
    strcat(result_line, str_level);
    strcat(result_line, time_string_buffer);
    strcat(result_line, message);
    strcat(result_line, "\n");

    print_str_to_file(log_file, result_line);

    return 1;
}

void log_close(FILE* log_file) { fclose(log_file); }

