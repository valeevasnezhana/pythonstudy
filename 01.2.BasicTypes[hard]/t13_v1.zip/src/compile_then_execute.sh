rm -f output_exec
gcc cipher.c -o output_exec && ./output_exec