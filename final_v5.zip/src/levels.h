#ifndef LEVELS_H
#define LEVELS_H

#include "common_utils.h"

typedef struct level_record_raw {
    int memory_level_index;
    int cell_amount;
    int protection_flag;
} t_level_record;

int read_level_record_from_file_at_index(FILE *file_pointer, int record_index, t_level_record* record);

int write_level_record_to_file_at_index(FILE *file_pointer, int record_index, t_level_record* record);

int append_new_level_record_to_file(char file_path[1024], t_level_record* new_record);

t_delete_status delete_level_record_with_memory_level_index(FILE *file_pointer, int memory_level_index);

int get_level_record_amount(FILE *input_file_pointer);

int display_level_records_from_file(FILE *input_file_pointer, int record_amount);

void print_level_record(t_level_record* record);

int scan_level_record_from_console(t_level_record* record);

int scan_and_append_new_level_record_to_file(char file_path[1024]);

t_update_status scan_and_update_level_record_with_id(FILE *file_pointer);

#endif
