#include <dirent.h>
#include <stdio.h>
#include "events.h"

int read_event_record_from_file_at_index(FILE *file_pointer, int record_index, t_event_record* record) {
    int return_code = 0;
    int read_obj_amount = 0;

    int offset = record_index * sizeof(t_event_record);
    fseek(file_pointer, offset, SEEK_SET);
    read_obj_amount += fread(record, sizeof(t_event_record), 1, file_pointer);
    rewind(file_pointer);

    if (read_obj_amount != 1) {
        return_code = 1;
    }
    return return_code;
}

int write_event_record_to_file_at_index(FILE *file_pointer, int record_index, t_event_record* record) {
    int return_code = 0;

    int written_obj_amount = 0;
    int offset = record_index * sizeof(t_event_record);
    fseek(file_pointer, offset, SEEK_SET);
    written_obj_amount = fwrite(record, sizeof(t_event_record), 1, file_pointer);
    fflush(file_pointer);
    rewind(file_pointer);

    if (written_obj_amount != 1) {
        return_code = 1;
    }
    return return_code;
}

int append_new_event_record_to_file(char file_path[1024], t_event_record* new_record) {
    int return_code = 0;

    FILE *output_file_pointer = fopen(file_path, "a+b");
    if (output_file_pointer == NULL) {
        return_code = 1;
    } else {
        print_event_record(new_record);
        int written_obj_amount = fwrite(new_record, sizeof(t_event_record), 1, output_file_pointer);
        fflush(output_file_pointer);
        fclose(output_file_pointer);
        if (written_obj_amount != 1) {
            return_code = 1;
        }
    }

    return return_code;
}

t_delete_status delete_event_record_with_id(FILE *file_pointer, int id) {
    int error_amount = 0;
    int record_was_found = 0;
    t_delete_status status = DELETE_SUCCESS;

    int initial_record_amount = get_event_record_amount(file_pointer);
    int write_record_index = 0;
    t_event_record current_record;

    for (int read_record_index = 0; read_record_index < initial_record_amount; read_record_index++) {
        error_amount += read_event_record_from_file_at_index(file_pointer, read_record_index, &current_record);
        if (error_amount > 0) {
            status = DELETE_INTERNAL_ERROR;
            break;
        }
        if (current_record.event_id == id) {
            record_was_found = 1;
            continue;
        }
        write_event_record_to_file_at_index(file_pointer, write_record_index, &current_record);
        write_record_index++;
    }
    if (record_was_found == 0 && status == DELETE_SUCCESS) {
        status = DELETE_ID_NOT_FOUND_ERROR;
    }
    return status;
}

int get_event_record_amount(FILE *input_file_pointer) {
    long file_size_in_bytes = get_file_size_in_bytes(input_file_pointer);
    int record_amount = (int) file_size_in_bytes / sizeof(t_event_record);
    return record_amount;
}

int display_event_records_from_file(FILE *input_file_pointer, int record_amount) {
    t_event_record record;
    int has_error = 0;
    for (int record_index = 0; record_index < record_amount; record_index++) {
        has_error = read_event_record_from_file_at_index(input_file_pointer, record_index, &record);
        if (has_error == 1) {
            break;
        } else {
            print_event_record(&record);
        }
    }
    return has_error;
}

void print_event_record(t_event_record* record) {
    if (record != NULL) {
        printf(
            "%d %d %d %s %s\n",
            record->event_id,
            record->module_id,
            record->new_module_status,
            record->status_change_date,
            record->status_change_time
        );
    }
}

int scan_event_record_from_console(t_event_record* record) {
    int received_values = 0;
    printf("event_id=");
    received_values = scanf("%d", &(record->event_id));
    if (received_values != 1) {
        return 1;
    }
    printf("module_id=");
    received_values = scanf("%d", &(record->module_id));
    if (received_values != 1) {
        return 1;
    }
    printf("new_module_status=");
    received_values = scanf("%d", &(record->new_module_status));
    if (received_values != 1) {
        return 1;
    }
    printf("status_change_date=");
    received_values = scanf("%11s", record->status_change_date);
    if (received_values != 1) {
        return 1;
    }
    printf("status_change_time=");
    received_values = scanf("%9s", record->status_change_time);
    if (received_values != 1) {
        return 1;
    }
    return 0;
}

int scan_and_append_new_event_record_to_file(char file_path[1024]) {
    int return_code = 0;
    t_event_record new_record;
    int scan_has_error = scan_event_record_from_console(&new_record);
    if (scan_has_error) {
        return_code = 1;
    } else {
        int append_has_error = append_new_event_record_to_file(file_path, &new_record);
        if (append_has_error) {
            return_code = 1;
        }
    }
    return return_code;
}

t_update_status scan_and_update_event_record_with_id(FILE *file_pointer) {
    t_update_status update_status = UPDATE_SUCCESS;
    t_event_record new_record, current_record;
    int record_was_found = 0;
    int scan_has_error = scan_event_record_from_console(&new_record);
    if (scan_has_error || file_pointer == NULL) {
        update_status = UPDATE_INPUT_ERROR;
    } else {
        int record_amount = get_event_record_amount(file_pointer);
        for (int record_index = 0; record_index < record_amount; record_index++) {
            int has_io_error = read_event_record_from_file_at_index(file_pointer, record_index, &current_record);
            if (has_io_error) {
                update_status = UPDATE_INTERNAL_ERROR;
                break;
            }
            if (current_record.event_id != new_record.event_id) {
                continue;
            }
            record_was_found = 1;
            has_io_error = write_event_record_to_file_at_index(file_pointer, record_index, &new_record);
            if (has_io_error) {
                update_status = UPDATE_INTERNAL_ERROR;
            }
            break;
        }
    }
    if (record_was_found == 0 && update_status == UPDATE_SUCCESS) {
        update_status = UPDATE_ID_NOT_FOUND_ERROR;
    }
    return update_status;
}

int extract_datetime_from_event(t_event_record* event_record, t_event_change_datetime* datetime) {
    int read_amount = 0;
    read_amount += sscanf(event_record->status_change_date, "%d.%d.%d",  &(datetime->day), &(datetime->month), &(datetime->year));
    read_amount += sscanf(event_record->status_change_date, "%d:%d:%d",  &(datetime->hour), &(datetime->minute), &(datetime->second));
    if (read_amount != 6) {
        return 1;
    } else {
        return 0;
    }
}

int left_datetime_is_less_than_right(t_event_change_datetime* left_datetime, t_event_change_datetime* right_datetime) {
    if (left_datetime->year != right_datetime->year) {
        return left_datetime->year < right_datetime->year;
    }
    if (left_datetime->month != right_datetime->month) {
        return left_datetime->month < right_datetime->month;
    }
    if (left_datetime->day != right_datetime->day) {
        return left_datetime->day < right_datetime->day;
    }
    if (left_datetime->hour != right_datetime->hour) {
        return left_datetime->hour < right_datetime->hour;
    }
    if (left_datetime->minute != right_datetime->minute) {
        return left_datetime->minute < right_datetime->minute;
    }
    return left_datetime->second < right_datetime->second;
}