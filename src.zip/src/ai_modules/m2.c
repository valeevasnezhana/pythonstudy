#jodmvef "n2.i"


wpje n2_g1()
{
    qsjoug("UFTU N2");
}

