#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LAT_ALPHABET_SIZE 26

void input();
void read_file(char *filename, int *incorrect_input);
void write_add_to_file(char *filename, int *incorrect_input);
void path_check(char *filename, int *incorrect_input);
void finder(char *dir_path, int shift);
void caesar(char *caesar_in, char *caesar_out, int shift);
void incorrect_input_checker(int incorrect_input);

int main() {
    input();
    return 0;
}

void input() {
    int signal = 0, s_res = 0, incorrect_input = 0;
    s_res = scanf("%d", &signal);
    char filename[256];
    while (signal != -1) {
        if (s_res == 1 && (signal == 1 || signal == 2 || signal == 3)) {
            if (signal == 1) {
                scanf("%s", filename);
                path_check(filename, &incorrect_input);
                read_file(filename, &incorrect_input);
                incorrect_input_checker(incorrect_input);
            } else if (signal == 2) {
                write_add_to_file(filename, &incorrect_input);
                read_file(filename, &incorrect_input);
                incorrect_input_checker(incorrect_input);
            } else if (signal == 3) {
                int caesar_shift;
                scanf("%s", filename);
                scanf("%d", &caesar_shift);
                finder(filename, caesar_shift);
            } else {
                incorrect_input_checker(1);
            }
        } else {
            incorrect_input_checker(1);
            scanf("%*[^\n]");
        }
        s_res = scanf("%d", &signal);
    }
}

void incorrect_input_checker(int incorrect_input) {
    if (incorrect_input) {
        printf("n/a\n");
    }
}


void path_check(char *filename, int *incorrect_input) {
    int sn = strlen(filename);
    if (filename[sn - 1] == 't' && filename[sn - 2] == 'x' && filename[sn - 3] == 't' && filename[sn - 4] == '.')
        *incorrect_input = 0;
    else
        *incorrect_input = 1;
}

void read_file(char *filename, int *incorrect_input) {
    FILE *file_pointer = fopen(filename, "r");
    char ch;
    if (file_pointer != NULL) {
        ch = fgetc(file_pointer);
        if (ch != EOF) {
            while (ch != EOF) {
                putchar(ch);
                ch = fgetc(file_pointer);
            }
            putchar('\n');
        } else {
            *incorrect_input = 0;
            printf("n/a\n");
        }
    } else {
        *incorrect_input = 1;
    }
    fclose(file_pointer);
}

void write_add_to_file(char *filename, int *incorrect_input) {
    char symbol, symbol2;
    if (*incorrect_input != 1) {
        FILE *file_pointer = fopen(filename, "a");
        if (file_pointer != NULL) {
            symbol2 = getchar();
            while ((symbol = getchar()) != '\n') {
                fputc(symbol, file_pointer);
            }
        } else {
            *incorrect_input = 1;
            symbol2 = getchar();
            symbol2 = ' ';
            while (symbol2 != '\n') {
                symbol2 = getchar();
            }
        }
        fclose(file_pointer);
    } else {
        symbol2 = getchar();
        symbol2 = ' ';
        while (symbol2 != '\n') {
            symbol2 = getchar();
        }
    }
}

void finder(char *dir_path, int shift) {
    char *pointer1, *pointer2, *caesar_in, *clean_in;
    char dir_path_cp[256], dir_path_cp1[256];
    DIR *dr;
    int rn;
    struct dirent *dir_read;
    dr = opendir(dir_path);
    if (dr != NULL) {
        while ((dir_read = readdir(dr)) != NULL) {
            pointer1 = strtok(dir_read->d_name, ".");
            pointer2 = strtok(NULL, ".");
            if (pointer2 != NULL) {
                rn = strcmp(pointer2, "c");
                if (rn == 0) {
                    caesar_in = strcat(pointer1, ".c");
                    strcpy(dir_path_cp, dir_path);
                    caesar_in = strcat(dir_path_cp, caesar_in);
                    caesar(caesar_in, pointer1, shift);
                    remove(caesar_in);
                    rename(pointer1, caesar_in);
                }
                rn = strcmp(pointer2, "h");
                if (rn == 0) {
                    clean_in = strcat(pointer1, ".h");
                    strcpy(dir_path_cp1, dir_path);
                    clean_in = strcat(dir_path_cp1, clean_in);
                    FILE *cl_aim = fopen(clean_in, "wb");
                    fclose(cl_aim);
                }
            }
        }
        closedir(dr);
    } else {
        printf("n/a\n");
    }
}

void caesar(char *caesar_in, char *caesar_out, int shift) {
    FILE *file1, *file2;
    file1 = fopen(caesar_in, "r");
    file2 = fopen(caesar_out, "w");
    char symbol;
    symbol = getc(file1);
    while (symbol != EOF) {
        if (symbol >= 'A' && symbol <= 'Z') {
            symbol = 'A' + (symbol - 'A' + shift) % LAT_ALPHABET_SIZE;
        } else if (symbol >= 'a' && symbol <= 'z') {
            symbol = 'a' + (symbol - 'a' + shift) % LAT_ALPHABET_SIZE;
        }
        fputc(symbol, file2);
        symbol = getc(file1);
    }
    fclose(file1);
    fclose(file2);
}